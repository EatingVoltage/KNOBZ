0.6 Prototypes

Midicontroller: 10Fader 20Knobs 4buttons
Laser Distance Sensor "AirKnob" sendig additional CC (expressiv midi controlling going down here!)
set range of knob on the fly via min and max settings
on the fly configurable CC and Channel
save config to 4 slots
small unit - aimed at tabletop synth guys
Midi Indicator LEDs show signal flow

connectivity: 
-USB Midi
TRS Midi Standart:
-Midi In
-Midi Out
-Midi Thru

Forwards midi to usb-midi and vice versa. 
this way acting as midi-Interface to PC / USB Host.            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。